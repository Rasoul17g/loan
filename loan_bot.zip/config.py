BOT_TOKEN = "7947017197:AAGQJH6Nr1vPxXV11QmjBv650PRROYNnmog"
DB_URL = "sqlite:///loans.db"
TIMEZONE = "Europe/Amsterdam"  # default timezone
# Optional: set the hour when the daily job runs (0-23), else it will run every 24h from start
DAILY_JOB_HOUR_UTC = None
