# loan_bot

A brief description of the project and how to run it.

## Requirements
- Python 3.9+

## Setup
```bash
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
```

## Run
```bash
python main.py
```

## License
MIT

